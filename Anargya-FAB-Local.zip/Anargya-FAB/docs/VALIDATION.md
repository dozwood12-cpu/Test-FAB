# Validasi implementasi — 27 Oktober 2026

Dilakukan pada lingkungan pengembangan, bukan deployment publik.

- Build Next.js berhasil.
- Enam unit test lulus: hash password, validasi anggota, tanggal akhir bulan/WIB, ambang jalur, jendela splitting, dan pemisahan tugas.
- Enam integration test PostgreSQL lulus: batas pengajuan, dokumen dan duplikasi, persetujuan bersamaan, advance, urgent/escalation idempotent, online evidence, nota hilang/cap, banding, audit append-only, email SMTP lokal, serta pengembalian sisa advance.
- Empat pengujian browser lulus: pengelolaan anggota dan pembelian sampai pencairan masing-masing pada desktop dan mobile. Termasuk penolakan akses dokumen milik anggota lain, Excel/PDF/ZIP, dan pemeriksaan halaman keuangan/katalog/panduan/notifikasi/audit/serah terima/akun.
- Seed data contoh dijalankan dua kali pada database uji dan selesai tanpa menggandakan pengajuan demo.
- `npm audit --omit=dev --audit-level=high` tidak menemukan kerentanan setelah override uuid untuk ExcelJS; ekspor Excel diuji setelah perubahan.
- Docker image berhasil dibangun dengan npm ci dan verifikasi TLS/checksum tetap aktif. Paket Compose web/worker/PostgreSQL dijalankan pada database dan volume uji terpisah.
- Login dan penambahan akun melalui image Docker berhasil; akun tetap ada setelah restart web/worker. Volume upload dapat ditulis oleh pengguna runtime non-root; akun dan berkas tetap ada setelah pembaruan image. Konfigurasi Caddy lolos validasi sintaks; sertifikat domain publik belum diterbitkan.
- Cadangan bootstrap database dipulihkan ke database sementara; akun FAB ditemukan. Database uji dibersihkan.

Keterbatasan: email diverifikasi dengan Mailpit lokal, bukan inbox anggota. Tidak ada layanan hosting/domain/SMTP produksi yang terhubung. Percobaan koneksi ke layanan tunnel sementara ditolak proxy jaringan (HTTP CONNECT 403). Tidak ada URL publik atau sertifikat domain produksi yang diterbitkan. Kontak PIC asli dan data operasional harus diisi Admin. Integrasi WhatsApp/Line dan arsip WORM eksternal belum dikonfigurasi.
